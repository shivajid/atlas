#
#This is used to restart, clean and start atlas with seed data
#

/usr/hdp/2.3.0.0-2557/atlas/bin/atlas_stop.py
rm -rf /var/lib/atlas/data
/usr/hdp/2.3.0.0-2557/atlas/bin/atlas_start.py
sleep 10
/usr/hdp/2.3.0.0-2557/atlas/bin/quick_start.py
